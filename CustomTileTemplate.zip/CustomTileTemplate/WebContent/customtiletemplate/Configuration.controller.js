// Copyright (c) 2009-2014 SAP SE, All Rights Reserved
(function() {
	"use strict";
	jQuery.sap.require("sap.ushell.components.tiles.utils");
	sap.ui
			.controller(
					"customtiletemplate.Configuration",
					{
						onConfigurationInputChange : function(c) {
							sap.ushell.components.tiles.utils.checkInput(this
									.getView(), c);
						},
						aDefaultObjects : [ {
							obj : "",
							name : ""
						} ],
						onInit : function() {
							var v = this.getView(), t = v.byId("targetUrl"), s = v
									.byId("navigation_semantic_objectInput"), r = sap.ushell.components.tiles.utils
									.getResourceBundleModel();
							v.setModel(r, "i18n");
							var b = r.getResourceBundle();
							v
									.setViewName("customtiletemplate.Configuration");
							sap.ushell.components.tiles.utils
									.createSemanticObjectModel(this, s,
											this.aDefaultObjects);
							s
									.attachChange(function(c) {
										var V = c.getSource().getValue();
										v
												.getModel()
												.setProperty(
														"/config/navigation_semantic_object",
														V);
									});
							function a(u) {
								return !u;
							}
							t.bindProperty("enabled", {
								formatter : a,
								path : "/config/navigation_use_semantic_object"
							});
							var i = new sap.ui.core.ListItem(
									{
										text : b
												.getText("configuration.tile_actions.table.target_type.url")
									});
							v.byId("targetTypeCB").addItem(i);
							i = new sap.ui.core.ListItem(
									{
										text : b
												.getText("configuration.tile_actions.table.target_type.intent")
									});
							v.byId("targetTypeCB").addItem(i);
						},
						onAfterRendering : function() {
							sap.ushell.components.tiles.utils
									.updateTooltipForDisabledProperties(this
											.getView());
							if(!this.getView().getModel().getProperty("/config/iconBase64"))this.getView().byId("buttonIconDelete").setVisible(false);
						},
						onValueHelpRequest : function(e) {
							sap.ushell.components.tiles.utils
									.objectSelectOnValueHelpRequest(this, e,
											false);
						},
						onCheckBoxChange : function(e) {
							var v = this.getView(), s = v
									.byId("navigation_semantic_objectInput"), m = s
									.getModel(), a = e.getSource()
									.getSelected();
							m.setProperty("/enabled", a);
							sap.ushell.components.tiles.utils.checkInput(this
									.getView(), e);
						},
						onIconValueHelpRequest : function(e) {
							sap.ushell.components.tiles.utils
									.iconSelectOnValueHelpRequest(this, e,
											false);
						},
						onSelectIconClose : function() {
							sap.ushell.components.tiles.utils
									.onSelectIconClose(this.getView());
						},
						onSelectIconOk : function() {
							sap.ushell.components.tiles.utils
									.onSelectIconOk(this.getView());
						},
						handleTargetTypeChange : function(t) {
							sap.ushell.components.tiles.utils
									.onTargetTypeChange(t);
						},
						onTileActionValueHelp : function(e) {
							sap.ushell.components.tiles.utils
									.objectSelectOnValueHelpRequest(this, e,
											true);
						},
						onTileActionIconValueHelp : function(e) {
							sap.ushell.components.tiles.utils
									.iconSelectOnValueHelpRequest(this, e, true);
						},
						addRow : function() {
							sap.ushell.components.tiles.utils
									.addTileActionsRow(this.getView());
						},
						deleteRow : function() {
							sap.ushell.components.tiles.utils
									.deleteTileActionsRow(this.getView());
						},
						handleUploadComplete: function(oEvent) {
							//busydialog
							//var file = $('#fileUploader-fu_data').attr("files")[0];
							var file= document.querySelector('input[type=file]').files[0];
							var reader=new FileReader();
							var that=this;
							reader.addEventListener("load", function () {
								//console.log(reader.result.length);//15424 too long
								if(reader.result.length<6000){
									that.getView().getModel().setProperty("/config/iconBase64",reader.result);
									  sap.m.MessageToast.show("File uploaded!");
									  that.getView().byId("customImage").setSrc(reader.result);
									  that.getView().byId("buttonIconDelete").setVisible(true);
									 
								}else{
									that.getView().getModel().setProperty("/config/iconBase64","");
									 sap.m.MessageToast.show("File size too big!Max 4KB!");
								}
								  
							}, false);

							if (file) {
								    reader.readAsDataURL(file);
							};
							
						},
						wrongFileType: function(oEvent) {							
							 sap.m.MessageToast.show("Wrong file type!");
						},
						handleUploadChange: function(oEvent) {
							 this.getView().byId("buttonIconDelete").setVisible(false);

							var oFileUploader = this.getView().byId("fileUploader");
							oFileUploader.upload();
						},

						handleDeletePress: function(oEvent) {
							var oFileUploader = this.getView().byId("fileUploader");
							oFileUploader.setValue("");
							 this.getView().byId("customImage").setSrc("");
							 this.getView().byId("buttonIconDelete").setVisible(false);
							 sap.m.MessageToast.show("Image deleted!");
						},
						getServerUrl:function(e){
							var url="/sap/opu/odata/SAP/Z_CUSTOMTILE_SRV/";
							//call odata to get the serverurl by key
							var that=this;
							
						
							if(e.getParameter("value")){
								var b=new sap.m.BusyDialog();
								b.open();
							
								new sap.ui.model.odata.ODataModel(url,true).read("/DataSet?$filter=Wa eq 'NAME eq `"+e.getParameter("value")+"`'",null,null,true,
										function(odata,response){
												
											if(odata.results.length>0){
												that.getView().getModel().setProperty("/config/serverUrlParameterInput",odata.results[0].Wa);
			
											}else {
												sap.m.MessageToast.show("Not found!");
												that.getView().getModel().setProperty("/config/serverKeyParameterInput","");
												that.getView().getModel().setProperty("/config/serverUrlParameterInput","");
											}
											//console.log(that.getView().getModel());
											b.close();
										},
										function(odata,response){
											that.getView().getModel().setProperty("/config/serverKeyParameterInput","");
											that.getView().getModel().setProperty("/config/serverUrlParameterInput","");
											sap.m.MessageToast.show("Not found!");
											b.close();
									});
								
								
						
							};
					

						},
						getServerUrlCMS:function(e){
							var url="/sap/opu/odata/SAP/Z_CUSTOMTILE_SRV/";
							//call odata to get the serverurl by key
							
							var that=this;
							if(e.getParameter("value")){
								var b=new sap.m.BusyDialog();
								b.open();
								new sap.ui.model.odata.ODataModel(url,true).read("/DataSet?$filter=Wa eq 'NAME eq `"+e.getParameter("value")+"`'",null,null,true,
										function(odata,response){
												
											if(odata.results.length>0){
												that.getView().getModel().setProperty("/config/serverCMSParameterInput",odata.results[0].Wa);
			
											}else {
												sap.m.MessageToast.show("Not found!");
												that.getView().getModel().setProperty("/config/serverKeyCMSParameterInput","");
												that.getView().getModel().setProperty("/config/serverCMSParameterInput","");
											}
											//console.log(that.getView().getModel());
											b.close();
										},
										function(odata,response){
											that.getView().getModel().setProperty("/config/serverKeyCMSParameterInput","");
											that.getView().getModel().setProperty("/config/serverCMSParameterInput","");
											sap.m.MessageToast.show("Not found!");
											b.close();
									});
							};
							that.getMobileURL();
							
						},
						getMobileURL:function(){		
							var that=this;
							var url="/sap/opu/odata/SAP/Z_CUSTOMTILE_SRV/";
							//mobileUrlParameterInput filling
							
							var b=new sap.m.BusyDialog();
							b.open();
							
							new sap.ui.model.odata.ODataModel(url,true).read("/DataSet?$filter=Wa eq 'NAME eq `"+"Z_FIORI_BO_MOBILE"+"`'",null,null,true,
									function(odata,response){
										if(odata.results.length>0){
											that.getView().getModel().setProperty("/config/mobileKeyParameterInput",odata.results[0].Wa);
											console.log("mobilekey",that.getView().getModel().getProperty("/config/mobileKeyParameterInput"));
											
										}else {
											sap.m.MessageToast.show("Z_FIORI_BO_MOBILE Not found!");
											that.getView().getModel().setProperty("/config/mobileKeyParameterInput","");
											
										}
										//console.log(that.getView().getModel());
										b.close();
									},
									function(odata,response){
										that.getView().getModel().setProperty("/config/mobileKeyParameterInput","");
										
										sap.m.MessageToast.show("Mobile key parameter not found!");
										b.close();
								});
							b.close();
							}
				
					});
}());
