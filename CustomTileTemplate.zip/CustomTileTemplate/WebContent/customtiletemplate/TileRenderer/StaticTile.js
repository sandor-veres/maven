/*!
 * Copyright (c) 2009-2014 SAP SE, All Rights Reserved
 */
jQuery.sap.declare("customtiletemplate.TileRenderer.StaticTile");
jQuery.sap.require("sap.ushell.library");
jQuery.sap.require("sap.ushell.ui.tile.TileBase");
sap.ushell.ui.tile.TileBase.extend("customtiletemplate.TileRenderer.StaticTile", {
	metadata : {
		library : "sap.ushell"
	}
});
