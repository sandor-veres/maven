// Copyright (c) 2009-2014 SAP SE, All Rights Reserved
(function() {
	"use strict";
	jQuery.sap.declare("customtiletemplate.TileRenderer.StaticTileRenderer");
	jQuery.sap.require("sap.ushell.ui.tile.TileBaseRenderer");
	customtiletemplate.TileRenderer.StaticTileRenderer = sap.ui.core.Renderer
			.extend(sap.ushell.ui.tile.TileBaseRenderer);
	customtiletemplate.TileRenderer.StaticTileRenderer.renderPart = function(r, c) {
		r.write("<span");
		r.addClass("sapUshellStaticTile");
		r.writeClasses();
		r.write(">");
		r.write("</span>");
		r.write("<div style='text-align: center;height: 85px; width: 180px;display: table-cell;vertical-align: middle;'>");
		if(c.getModel().oData.config.iconBase64)r.write("<img style='max-width:180px;max-height:85px;' src='"+c.getModel().getData().config.iconBase64+"'/>")
		r.write("</div>");
	};
}());
