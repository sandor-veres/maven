jQuery.sap.declare("com.act.ui5.splitapp.util.Formatter");// sync loading

com.act.ui5.splitapp.util.Formatter = {
		test : function(value) {
			if(value){
				return value;
			}
	}
};