sap.ui.define([ "sap/ui/core/util/MockServer" ], function(MockServer) {
	"use strict";
	return {
		init : function() {
			var oMockServer = new MockServer({
				rootUri : "/V3/Northwind/Northwind.svc"
			});
			oMockServer.simulate("../model/NorthWind.xml", {
				sMockdataBaseUrl : "../model/",
				bGenerateMissingMockData : true
			});
			oMockServer.start();
		}
	};
});
