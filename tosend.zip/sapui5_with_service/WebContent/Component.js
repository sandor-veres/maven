/**
 * @author Sandor Veres
 * 
**/
sap.ui.define([ "sap/ui/core/UIComponent"], function(
	Component,mockService) {
	"use strict";
	return Component.extend("com.act.ui5.splitapp.Component", {
		metadata : {
			manifest : "json"
		},
		init:function(){
			Component.prototype.init.apply(this,arguments);
			this.getRouter().initialize();
		},
		createContent : function() {

			//make the mock loading 
			return new sap.ui.view({
				id : "Main",
				viewName : "com.act.ui5.splitapp.view.Main",
				type : sap.ui.core.mvc.ViewType.XML
			});
			
		
		}

	})
});
