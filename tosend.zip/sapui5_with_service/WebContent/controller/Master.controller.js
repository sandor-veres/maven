sap.ui.define([ 
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
	], 
	function(Controller,MesageBox) {
	"use strict";
	return Controller.extend("com.act.ui5.splitapp.controller.Master", {
	
		
		onInit : function() {
		//this is using direct odata without calling the read
			var oModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZATTENDANCE_SRV ',{
				 json     : true,
				});
			
			
			
			
		 var oModel = new sap.ui.model.odata.v2.ODataModel('/proxy/https/services.odata.org/V3/Northwind/Northwind.svc',{json:true,useBatch:false});
		 this.getView().setModel(oModel);
	
		},

		onAfterRendering : function() {
		},
		onSearch:function(){
			
		},
		//liveChange used
		onFilter : function(){
			
		},
		//routing
		onSelectItem: function(oEvt){
			var itemId=oEvt.getSource().getBindingContext().getObject().OrderID;
			sap.ui.core.UIComponent.getRouterFor(this).navTo("Detail",{orderId:itemId});

			
		}


	})
});