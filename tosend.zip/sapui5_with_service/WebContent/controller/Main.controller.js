
sap.ui.define([ 
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
	], 
	function(Controller,ODataModel,Filter,Formatter,MessageBox) {
	"use strict";
	return Controller.extend("com.act.ui5.splitapp.controller.Main", {
	
		onInit : function() {
			 this.getView().addStyleClass('sapUiSizeCompact');
		},

		onAfterRendering : function() {
		}
	})
});