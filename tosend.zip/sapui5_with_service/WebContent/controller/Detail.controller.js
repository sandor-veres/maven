
sap.ui.define([ 
	"com/act/ui5/splitapp/controller/Base.controller",
	"sap/ui/model/odata/v2/ODataModel", 
	"sap/ui/model/Filter",
	"sap/m/MessageBox"
	], 
	function(BaseController,ODataModel,Filter,Formatter,MessageBox) {
	"use strict";
	return BaseController.extend("com.act.ui5.splitapp.controller.Detail", {

		onInit : function() {
			jQuery.sap.log.setLevel(jQuery.sap.log.Level.DEBUG);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Detail").attachPatternMatched(this._onRouteMatched, this);
			this.hello();
		},

		onAfterRendering : function() {
		
		},
		_onRouteMatched:function(oEvt){
			var busy=new sap.m.BusyDialog();
			var that=this;
			busy.open();
			var itemId=oEvt.getParameter("arguments").orderId;
			//this can be a singleton if one service is used
			var oModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZATTENDANCE_SRV ',{useBatch:false});
			
			
			oModel.read("/Orders("+itemId+")",{
				urlParameters:["$expand=Order_Details,Customer,Shipper"],
				success:function(oData,oResponse){
				console.log(oData);
				that.getView().setModel(new sap.ui.model.json.JSONModel(oData));
				busy.close();
			
			},
			error:function(oResponse){
				sap.m.MessageToast("Error on service call!");
				busy.close();
				
			}
		}

	);
		}

		
	})
});